scripts present in `/coco/` taken from : [torchvision](https://github.com/pytorch/vision/tree/master/references/detection) and modified for use with this particular task.
